from django.apps import AppConfig


class ApsokaraConfig(AppConfig):
    name = 'apsokara'
