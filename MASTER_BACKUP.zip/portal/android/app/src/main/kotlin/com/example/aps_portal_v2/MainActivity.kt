package com.example.aps_portal_v2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
